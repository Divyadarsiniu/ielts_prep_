import React, { useState, useRef, useEffect } from "react";
import { 
  Flame, 
  BookOpen, 
  CheckCircle2, 
  ArrowRight, 
  Clock, 
  Trophy, 
  Bell, 
  Calendar,
  PlayCircle,
  Award,
  ChevronRight,
  TrendingUp,
  Info,
  ChevronDown,
  Headphones,
  FileText,
  Mic2,
  Eye,
  Settings,
  Target,
  Users,
  Lock,
  Star,
  Zap,
  Check
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import confetti from "canvas-confetti";

// --- Types ---
type OnboardingStep = "welcome" | "age" | "exam-date" | "plan-selection";
type AppFlow = "onboarding" | "dashboard" | "video" | "test" | "improvement" | "feedback" | "decision" | "summary";

interface UserProfile {
  age?: string;
  examDate?: string;
  uniDeadline?: string;
  visaExpiry?: string;
  plan?: string;
}

// --- Helpers ---

const getTimelineAnalysis = (dateStr: string) => {
  const today = new Date();
  const exam = new Date(dateStr);
  const diffTime = exam.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  let intensity = "Balanced";
  let message = "You have a comfortable window to master all modules.";
  
  if (diffDays <= 30) {
    intensity = "CRITICAL";
    message = "You're in the final stretch. Focus on intensive mock tests.";
  } else if (diffDays <= 90) {
    intensity = "HIGH";
    message = "Steady daily practice is crucial for your target score.";
  } else if (diffDays > 180) {
    intensity = "FOUNDATIONAL";
    message = "Great start! We'll build your skills from the ground up.";
  }
  
  return { days: diffDays, intensity, message };
};

// --- Components ---

const ProgressBar = ({ label, value, color = "bg-zinc-900" }: { label: string, value: number, color?: string }) => (
  <div className="space-y-1">
    <div className="flex justify-between text-[10px] font-bold text-zinc-400 uppercase tracking-tighter">
      <span>{label}</span>
      <span>{value}%</span>
    </div>
    <div className="h-1.5 w-full bg-zinc-100 rounded-full overflow-hidden">
      <motion.div 
        initial={{ width: 0 }}
        animate={{ width: `${value}%` }}
        className={`h-full ${color}`}
      />
    </div>
  </div>
);

const PathNode = ({ day, status, label, icon: Icon, onClick }: { 
  day: number, 
  status: 'completed' | 'current' | 'locked', 
  label: string,
  icon: any,
  onClick?: () => void
}) => {
  const isCurrent = status === 'current';
  const isCompleted = status === 'completed';
  const isLocked = status === 'locked';

  return (
    <div className="flex flex-col items-center relative group">
      {/* Connector line (handled by parent mostly, but can add small stubs) */}
      <motion.button
        whileHover={!isLocked ? { scale: 1.1 } : {}}
        whileTap={!isLocked ? { scale: 0.95 } : {}}
        onClick={onClick}
        disabled={isLocked}
        className={`
          w-16 h-16 rounded-full flex items-center justify-center relative z-10
          transition-all duration-300 border-b-4
          ${isCompleted ? 'bg-green-500 border-green-700 text-white' : ''}
          ${isCurrent ? 'bg-zinc-900 border-zinc-950 text-white shadow-xl shadow-zinc-200 scale-110' : ''}
          ${isLocked ? 'bg-zinc-100 border-zinc-200 text-zinc-300' : ''}
        `}
      >
        {isCompleted ? <Check className="w-8 h-8 stroke-[3]" /> : <Icon className="w-7 h-7" />}
        
        {isCurrent && (
          <motion.div
            layoutId="current-glow"
            className="absolute -inset-2 bg-zinc-900/10 rounded-full -z-10"
            animate={{ scale: [1, 1.15, 1], opacity: [0.5, 0.2, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
      </motion.button>
      
      <div className="mt-3 text-center">
        <p className={`text-[10px] font-black uppercase tracking-widest ${isLocked ? 'text-zinc-300' : 'text-zinc-500'}`}>
          Day {day}
        </p>
        <p className={`text-xs font-bold leading-none mt-0.5 ${isLocked ? 'text-zinc-300' : 'text-zinc-900'}`}>
          {label}
        </p>
      </div>
    </div>
  );
};

const MilestoneNode = ({ label, isLocked }: { label: string, isLocked: boolean }) => (
  <div className="flex flex-col items-center py-6">
    <div className={`
      px-6 py-4 rounded-3xl border-2 border-dashed flex items-center gap-3 transition-colors
      ${isLocked ? 'bg-zinc-50 border-zinc-100 text-zinc-300' : 'bg-yellow-50 border-yellow-200 text-yellow-700'}
    `}>
      <Trophy className={`w-5 h-5 ${isLocked ? 'opacity-30' : 'animate-bounce'}`} />
      <div className="text-left">
        <p className="text-[10px] font-black uppercase tracking-widest">Milestone Unlock</p>
        <p className="text-sm font-bold leading-none mt-0.5">{label}</p>
      </div>
    </div>
  </div>
);

const Onboarding: React.FC<{ onComplete: (profile: UserProfile) => void }> = ({ onComplete }) => {
  const [step, setStep] = useState<"welcome" | "age" | "exam-date" | "deadlines" | "plan-selection">("welcome");
  const [profile, setProfile] = useState<UserProfile>({});

  const nextStep = (update: Partial<UserProfile>, next: "welcome" | "age" | "exam-date" | "deadlines" | "plan-selection" | "complete") => {
    const newProfile = { ...profile, ...update };
    setProfile(newProfile);
    if (next === "complete") {
      onComplete(newProfile);
    } else {
      setStep(next);
    }
  };

  return (
    <div className="flex flex-col h-full p-8 justify-center space-y-12">
      <AnimatePresence mode="wait">
        {step === "welcome" && (
          <motion.div 
            key="welcome"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="text-center space-y-6"
          >
            <div className="w-20 h-20 bg-zinc-900 rounded-3xl mx-auto flex items-center justify-center rotate-3 shadow-xl">
              <span className="text-3xl text-white font-black italic">L</span>
            </div>
            <div className="space-y-2">
              <h1 className="text-3xl font-black tracking-tighter uppercase italic leading-none">Leap Scholar</h1>
              <p className="text-zinc-500 font-medium">IELTS Preparation Reimagined</p>
            </div>
            <button 
              onClick={() => setStep("age")}
              className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2"
            >
              Get Started
              <ArrowRight className="w-5 h-5" />
            </button>
          </motion.div>
        )}

        {step === "age" && (
          <motion.div 
            key="age"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-zinc-900">Specify your age</h2>
              <p className="text-zinc-500 text-sm">Personalizing your learning pace.</p>
            </div>
            <div className="grid grid-cols-1 gap-3">
              {["18 - 20", "21 - 23", "23 - 26"].map(age => (
                <button 
                  key={age}
                  onClick={() => nextStep({ age }, "exam-date")}
                  className="w-full p-5 bg-white border border-zinc-200 rounded-2xl text-left font-bold hover:border-zinc-900 transition-colors flex justify-between items-center"
                >
                  {age}
                  <ChevronRight className="w-4 h-4 text-zinc-300" />
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {step === "exam-date" && (
          <motion.div 
            key="date"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-zinc-900">IELTS Exam Date</h2>
              <p className="text-zinc-500 text-sm">Your primary preparation deadline.</p>
            </div>
            <div className="space-y-4">
              <input 
                type="date" 
                min={new Date().toISOString().split('T')[0]}
                className="w-full p-5 bg-zinc-50 border border-zinc-200 rounded-2xl font-medium outline-none focus:ring-2 focus:ring-zinc-900"
                onChange={(e) => setProfile({ ...profile, examDate: e.target.value })}
              />
              <button 
                disabled={!profile.examDate}
                onClick={() => setStep("deadlines")}
                className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold disabled:opacity-50 transition-opacity"
              >
                Continue
              </button>
            </div>
          </motion.div>
        )}

        {step === "deadlines" && (
          <motion.div 
            key="deadlines"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-zinc-900">Critical Timelines</h2>
              <p className="text-zinc-500 text-sm">Adding these helps us prioritize your modules.</p>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">University Application Deadline</label>
                <input 
                  type="date" 
                  className="w-full p-4 bg-zinc-50 border border-zinc-200 rounded-xl font-medium"
                  onChange={(e) => setProfile({ ...profile, uniDeadline: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Visa Expiry Date</label>
                <input 
                  type="date" 
                  className="w-full p-4 bg-zinc-50 border border-zinc-200 rounded-xl font-medium"
                  onChange={(e) => setProfile({ ...profile, visaExpiry: e.target.value })}
                />
              </div>
              <button 
                onClick={() => nextStep({}, "plan-selection")}
                className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold"
              >
                Analyze Roadmap
              </button>
            </div>
          </motion.div>
        )}

        {step === "plan-selection" && (
          <motion.div 
            key="plan"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="space-y-2">
              <h2 className="text-2xl font-bold italic text-zinc-900">Personalized Roadmap</h2>
              <p className="text-zinc-500 text-sm">Roadmap generated based on your exam, uni deadline, and visa status.</p>
            </div>
            
            <div className="bg-zinc-900 text-white p-8 rounded-[2.5rem] space-y-6 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Target className="w-24 h-24" />
              </div>
              
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Preparation Window</span>
                <h3 className="text-5xl font-black italic uppercase tracking-tighter">
                  {getTimelineAnalysis(profile.examDate!).days}
                </h3>
                <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] pt-1">Days Until Exam</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-white/5 p-3 rounded-xl border border-white/10">
                  <span className="text-[8px] text-zinc-500 uppercase font-bold block">Uni Deadline</span>
                  <span className="text-xs font-bold text-zinc-300">
                    {profile.uniDeadline ? new Date(profile.uniDeadline).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) : 'N/A'}
                  </span>
                </div>
                <div className="bg-white/5 p-3 rounded-xl border border-white/10">
                  <span className="text-[8px] text-zinc-500 uppercase font-bold block">Visa Expiry</span>
                  <span className="text-xs font-bold text-zinc-300">
                    {profile.visaExpiry ? new Date(profile.visaExpiry).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) : 'N/A'}
                  </span>
                </div>
              </div>

              <div className="bg-white/5 p-4 rounded-2xl">
                <p className="text-xs text-zinc-400 leading-relaxed italic">
                  "{getTimelineAnalysis(profile.examDate!).message}"
                </p>
              </div>

              <button 
                onClick={() => nextStep({ plan: `${getTimelineAnalysis(profile.examDate!).days} Days Prep` }, "complete")}
                className="w-full bg-white text-zinc-900 py-4 rounded-xl font-black uppercase tracking-tight flex items-center justify-center gap-2"
              >
                Let's Start Learning
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const App: React.FC = () => {
  const [flow, setFlow] = useState<AppFlow>("onboarding");
  const [profile, setProfile] = useState<UserProfile>({});
  const [streak, setStreak] = useState(12);
  const [progress, setProgress] = useState({ overall: 45, listening: 62, reading: 38, writing: 25, speaking: 55 });

  const completeTask = () => {
    setFlow("feedback");
    setStreak(prev => prev + 1);
    setProgress(prev => ({
      ...prev,
      overall: prev.overall + 2,
      listening: prev.listening + 5
    }));
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ["#000000", "#71717a"]
    });
  };

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans selection:bg-zinc-200">
      <div className="max-w-md mx-auto bg-white min-h-screen border-x border-zinc-200 flex flex-col relative">
        
        {flow === "onboarding" ? (
          <Onboarding onComplete={(p) => { setProfile(p); setFlow("dashboard"); }} />
        ) : (
          <>
            {/* Header */}
            <header className="p-6 border-b border-zinc-100 sticky top-0 bg-white/80 backdrop-blur-md z-10 flex justify-between items-center">
              <div>
                <h1 className="text-xs font-bold tracking-widest text-zinc-400 uppercase">Leap Scholar</h1>
                <p className="text-lg font-black italic tracking-tighter leading-none">PULSE</p>
              </div>
              <div className="flex gap-2">
                <div className="bg-zinc-100 px-3 py-1 rounded-full flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 fill-current text-zinc-900" />
                  <span className="text-xs font-bold">{streak}</span>
                </div>
                <div className="bg-zinc-900 text-white p-2 rounded-full">
                  <Settings className="w-4 h-4" />
                </div>
              </div>
            </header>

            <main className="flex-1">
              <AnimatePresence mode="wait">
                {flow === "dashboard" && (
                  <motion.div 
                    key="dashboard" 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col h-full"
                  >
                    {/* Top Stats Bar */}
                    <div className="px-6 py-4 bg-white/80 backdrop-blur-md sticky top-[73px] z-20 border-b border-zinc-100 flex items-center justify-between">
                      <div className="flex gap-4">
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black text-zinc-400 uppercase tracking-widest">Level</span>
                          <span className="text-sm font-black italic">B2 → C1</span>
                        </div>
                        <div className="w-[1px] h-8 bg-zinc-100" />
                        <div className="flex flex-col">
                          <span className="text-[8px] font-black text-zinc-400 uppercase tracking-widest">Mastery</span>
                          <span className="text-sm font-black italic">{progress.overall}%</span>
                        </div>
                      </div>
                      
                      {/* Deadline Countdown Badges */}
                      <div className="flex gap-1.5 overflow-x-auto no-scrollbar max-w-[180px]">
                        {profile.examDate && (
                          <div className="bg-zinc-900 text-white px-2 py-1 rounded-lg shrink-0 flex items-center gap-1.5 shadow-sm">
                            <Target className="w-3 h-3 text-red-400" />
                            <span className="text-[9px] font-black">{getTimelineAnalysis(profile.examDate).days}d</span>
                          </div>
                        )}
                        {profile.uniDeadline && (
                          <div className="bg-zinc-100 text-zinc-600 px-2 py-1 rounded-lg shrink-0 flex items-center gap-1.5">
                            <BookOpen className="w-3 h-3 text-blue-500" />
                            <span className="text-[9px] font-black">{getTimelineAnalysis(profile.uniDeadline).days}d</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex-1 overflow-y-auto no-scrollbar py-12 px-6 flex flex-col items-center">
                      <div className="w-full max-w-xs space-y-0 relative">
                        {/* Vertical Path Line */}
                        <div className="absolute left-1/2 top-0 bottom-0 w-3 bg-zinc-50 -translate-x-1/2 -z-0 rounded-full" />
                        <div className="absolute left-1/2 top-0 h-[45%] w-3 bg-green-100 -translate-x-1/2 -z-0 rounded-full transition-all duration-1000" />

                        <div className="relative space-y-12">
                          <div className="flex flex-col items-center">
                             <PathNode 
                                day={1} 
                                status="completed" 
                                label="Collocations" 
                                icon={BookOpen} 
                              />
                          </div>

                          <div className="flex justify-center -translate-x-12">
                            <PathNode 
                              day={2} 
                              status="completed" 
                              label="Listening Flow" 
                              icon={Headphones} 
                            />
                          </div>

                          <div className="flex justify-center translate-x-12">
                            <PathNode 
                              day={3} 
                              status="current" 
                              label="Active Mission" 
                              icon={Zap} 
                              onClick={() => setFlow("task")}
                            />
                          </div>

                          <MilestoneNode label="Weekend Mock Test" isLocked={true} />

                          <div className="flex justify-center -translate-x-8">
                            <PathNode 
                              day={4} 
                              status="locked" 
                              label="Coherence" 
                              icon={FileText} 
                            />
                          </div>

                          <div className="flex justify-center translate-x-10">
                            <PathNode 
                              day={5} 
                              status="locked" 
                              label="Tone & Style" 
                              icon={Mic2} 
                            />
                          </div>

                          <div className="flex justify-center">
                            <PathNode 
                              day={6} 
                              status="locked" 
                              label="Speed Reading" 
                              icon={Eye} 
                            />
                          </div>

                          <MilestoneNode label="Advanced Module" isLocked={true} />
                        </div>
                      </div>
                    </div>

                    {/* Floating Start Button */}
                    <div className="p-6 bg-gradient-to-t from-white via-white to-transparent sticky bottom-0">
                      <button 
                        onClick={() => setFlow("video")}
                        className="w-full bg-zinc-900 text-white py-5 rounded-[2rem] font-black uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl active:scale-95 transition-transform"
                      >
                        <PlayCircle className="w-6 h-6 text-green-400" />
                        Start Daily Task
                      </button>
                    </div>
                  </motion.div>
                )}

                {flow === "video" && (
                  <motion.div 
                    key="video" 
                    initial={{ opacity: 0, x: 20 }} 
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="flex flex-col h-full"
                  >
                    <div className="p-6 space-y-6">
                      <div className="flex justify-between items-center text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                        <span>Step 1: Video Session</span>
                        <span>12:00 mins</span>
                      </div>
                      
                      <div className="aspect-video bg-zinc-900 rounded-[2rem] overflow-hidden relative group cursor-pointer flex items-center justify-center">
                        <img 
                          src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=1000" 
                          alt="Video thumbnail"
                          className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
                        />
                        <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30 group-hover:scale-110 transition-transform relative z-10">
                          <PlayCircle className="w-10 h-10 text-white fill-white" />
                        </div>
                        <div className="absolute bottom-6 left-6 right-6">
                          <p className="text-white font-black text-lg italic tracking-tight leading-none">Mastering Advanced Collocations</p>
                          <p className="text-white/60 text-[10px] font-bold uppercase mt-1">IELTS Band 8.0 Strategy</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h4 className="text-xs font-black uppercase tracking-widest text-zinc-400">Key Takeaways</h4>
                        <div className="space-y-2">
                          {[
                            "Avoid 'very' - use 'exceptionally' or 'vastly'",
                            "Pairing verbs correctly (e.g., 'Commit a crime')",
                            "Academic vs Informal contexts"
                          ].map((item, i) => (
                            <div key={i} className="flex gap-3 items-start p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                              <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                              <p className="text-sm font-medium text-zinc-600 leading-tight">{item}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="mt-auto p-6 bg-white border-t border-zinc-100">
                      <button 
                        onClick={() => setFlow("test")}
                        className="w-full bg-zinc-900 text-white py-5 rounded-[2rem] font-black uppercase tracking-widest flex items-center justify-center gap-2"
                      >
                        Next: Test Series
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                )}

                {flow === "test" && (
                  <motion.div 
                    key="test" 
                    initial={{ opacity: 0, x: 20 }} 
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="p-6 space-y-10"
                  >
                    <div className="space-y-4">
                      <div className="flex justify-between items-center text-[10px] font-black text-zinc-400 uppercase tracking-widest">
                        <span>Step 2: Test Series</span>
                        <span>Part 1 of 5</span>
                      </div>
                      <div className="h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                        <div className="h-full bg-zinc-900 w-1/5" />
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div className="space-y-4">
                        <h3 className="text-2xl font-black italic tracking-tighter leading-tight">
                          "The implementation of the new policy caused a _____ shift in public opinion."
                        </h3>
                        <p className="text-xs font-medium text-zinc-500 italic">Select the most appropriate academic collocation from the video session.</p>
                      </div>

                      <div className="grid grid-cols-1 gap-3">
                        {[
                          { text: "Significant", correct: true },
                          { text: "Big", correct: false },
                          { text: "Huge", correct: false },
                          { text: "Massive", correct: false }
                        ].map(opt => (
                          <button 
                            key={opt.text} 
                            onClick={() => {}} 
                            className="w-full p-6 border-2 border-zinc-100 rounded-3xl text-left font-black italic text-lg hover:border-zinc-900 hover:bg-zinc-50 transition-all group"
                          >
                            <div className="flex justify-between items-center">
                              <span>{opt.text}</span>
                              <div className="w-6 h-6 rounded-full border-2 border-zinc-100 group-hover:border-zinc-900" />
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    <button 
                      onClick={() => setFlow("improvement")}
                      className="w-full bg-zinc-900 text-white py-5 rounded-[2rem] font-black uppercase tracking-widest"
                    >
                      Check Answer
                    </button>
                  </motion.div>
                )}

                {flow === "improvement" && (
                  <motion.div 
                    key="improvement" 
                    initial={{ opacity: 0, scale: 0.95 }} 
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="p-6 flex flex-col h-full"
                  >
                    <div className="flex-1 space-y-8 py-8">
                      <div className="text-center space-y-2">
                        <div className="inline-flex p-3 bg-green-100 text-green-600 rounded-2xl mb-2">
                          <TrendingUp className="w-8 h-8" />
                        </div>
                        <h2 className="text-3xl font-black italic tracking-tighter uppercase">Improvement Scales</h2>
                        <p className="text-zinc-500 font-medium text-sm">Real-time skill calibration based on your performance.</p>
                      </div>

                      <div className="space-y-8">
                        <div className="bg-zinc-50 p-6 rounded-[2.5rem] border border-zinc-100 space-y-6">
                          <div className="space-y-4">
                            <div className="flex justify-between items-end">
                              <div>
                                <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Vocabulary Range</p>
                                <p className="text-lg font-black italic">6.5 → 7.5</p>
                              </div>
                              <span className="text-green-500 font-black text-sm">+1.0 Band</span>
                            </div>
                            <div className="h-4 w-full bg-zinc-200 rounded-full overflow-hidden relative">
                              <div className="absolute inset-0 bg-green-500/10" />
                              <motion.div 
                                initial={{ width: "65%" }}
                                animate={{ width: "75%" }}
                                transition={{ duration: 1.5, ease: "easeOut" }}
                                className="h-full bg-green-500 relative"
                              >
                                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-white/20 animate-pulse" />
                              </motion.div>
                            </div>
                          </div>

                          <div className="space-y-4">
                            <div className="flex justify-between items-end">
                              <div>
                                <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Grammatical Accuracy</p>
                                <p className="text-lg font-black italic">7.0 → 7.0</p>
                              </div>
                              <span className="text-zinc-400 font-black text-sm">Steady</span>
                            </div>
                            <div className="h-4 w-full bg-zinc-200 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: "70%" }}
                                animate={{ width: "70%" }}
                                className="h-full bg-zinc-900"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="bg-zinc-900 text-white p-6 rounded-[2.5rem] flex items-center gap-4 relative overflow-hidden">
                          <div className="absolute right-0 top-0 p-4 opacity-10">
                            <Star className="w-16 h-16" />
                          </div>
                          <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center shrink-0">
                            <Trophy className="w-6 h-6 text-yellow-400" />
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Daily XP</p>
                            <p className="text-lg font-black">+250 Streak XP</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-6">
                      <button 
                        onClick={() => { setFlow("feedback"); completeTask(); }}
                        className="w-full bg-zinc-900 text-white py-5 rounded-[2rem] font-black uppercase tracking-widest"
                      >
                        See Today's Summary
                      </button>
                    </div>
                  </motion.div>
                )}

                {flow === "feedback" && (
                  <motion.div 
                    key="feedback" 
                    initial={{ scale: 0.9, opacity: 0 }} 
                    animate={{ scale: 1, opacity: 1 }}
                    className="p-6 space-y-8 flex flex-col items-center text-center justify-center h-full pt-12"
                  >
                    <div className="relative">
                      <div className="w-24 h-24 bg-zinc-900 rounded-full flex items-center justify-center shadow-2xl">
                        <Trophy className="w-12 h-12 text-white" />
                      </div>
                      <motion.div 
                        initial={{ scale: 0 }} 
                        animate={{ scale: 1 }} 
                        transition={{ delay: 0.5 }}
                        className="absolute -top-2 -right-2 bg-green-500 text-white px-3 py-1 rounded-full text-[10px] font-black"
                      >
                        +150 XP
                      </motion.div>
                    </div>

                    <div className="space-y-2">
                      <h2 className="text-3xl font-black italic uppercase tracking-tighter">Day {streak} Locked!</h2>
                      <p className="text-zinc-500 font-medium">Your consistency is building a real competitive edge.</p>
                    </div>

                    <div className="bg-zinc-50 p-6 rounded-[2rem] w-full border border-zinc-100 space-y-4">
                      <div className="flex justify-between items-center text-[10px] font-bold text-zinc-400">
                        <span>ESTIMATED BAND SCORE</span>
                        <span className="text-zinc-900">7.0 → 7.5</span>
                      </div>
                      <div className="h-2 bg-zinc-200 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: "65%" }} 
                          animate={{ width: "68%" }} 
                          className="h-full bg-zinc-900" 
                        />
                      </div>
                      <p className="text-[10px] text-zinc-400 italic">"You're improving faster than 82% of students this week."</p>
                    </div>

                    <button 
                      onClick={() => setFlow("decision")}
                      className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2"
                    >
                      Next Step
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </motion.div>
                )}

                {flow === "decision" && (
                  <motion.div 
                    key="decision" 
                    initial={{ opacity: 0, y: 20 }} 
                    animate={{ opacity: 1, y: 0 }}
                    className="p-6 space-y-8 flex flex-col justify-center h-full"
                  >
                    <div className="text-center space-y-4">
                      <div className="w-16 h-16 bg-zinc-100 rounded-2xl mx-auto flex items-center justify-center">
                        <Clock className="w-8 h-8 text-zinc-900" />
                      </div>
                      <h3 className="text-2xl font-bold">You've done the work today.</h3>
                      <p className="text-zinc-500 text-sm">A 12-minute win is still a win. Habits are built on these moments.</p>
                    </div>

                    <div className="space-y-3">
                      <button 
                        onClick={() => setFlow("summary")}
                        className="w-full py-4 border border-zinc-200 rounded-2xl font-bold text-zinc-500 hover:bg-zinc-50"
                      >
                        I'm done for today
                      </button>
                      <button 
                        onClick={() => { setFlow("summary"); confetti(); }}
                        className="w-full py-4 bg-zinc-900 text-white rounded-2xl font-bold flex justify-between items-center px-6"
                      >
                        <span>One more quick boost (+5 min)</span>
                        <span className="bg-white/20 text-[10px] px-2 py-0.5 rounded uppercase">Extra XP</span>
                      </button>
                    </div>

                    <div className="bg-blue-50/50 p-5 rounded-2xl border border-blue-100 flex gap-4">
                      <Info className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                      <p className="text-[11px] text-blue-700 leading-relaxed font-medium">
                        <strong>Daily Streak Reminder:</strong> If you stop now, we'll nudge you tomorrow at 8:00 AM to keep your {streak}-day streak alive.
                      </p>
                    </div>
                  </motion.div>
                )}

                {flow === "summary" && (
                  <motion.div 
                    key="summary" 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }}
                    className="p-6 space-y-10 pb-12"
                  >
                    <div className="text-center space-y-6">
                      <div className="inline-flex p-4 bg-zinc-900 text-white rounded-full relative">
                        <Award className="w-10 h-10" />
                        <motion.div 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute -top-1 -right-1 bg-green-500 text-[10px] font-black px-2 py-0.5 rounded-full border-2 border-white"
                        >
                          DAY 1 COMPLETE
                        </motion.div>
                      </div>
                      <div className="space-y-2">
                        <h2 className="text-3xl font-black italic uppercase tracking-tighter">Level 1 Mastery</h2>
                        <p className="text-zinc-500 font-medium">You've unlocked the first step of your {getTimelineAnalysis(profile.examDate!).days}-day mission.</p>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div className="space-y-2">
                        <div className="flex justify-between items-end">
                          <h4 className="text-xs font-bold uppercase tracking-widest text-zinc-400">Preparation Velocity</h4>
                          <span className="text-2xl font-black">{progress.overall}%</span>
                        </div>
                        <div className="h-3 w-full bg-zinc-100 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }} 
                            animate={{ width: `${progress.overall}%` }} 
                            className="h-full bg-zinc-900" 
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100">
                          <p className="text-[8px] font-black text-zinc-400 uppercase tracking-widest mb-1">Target Uni</p>
                          <p className="text-xs font-bold">{profile.uniDeadline ? new Date(profile.uniDeadline).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) : 'N/A'}</p>
                        </div>
                        <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100">
                          <p className="text-[8px] font-black text-zinc-400 uppercase tracking-widest mb-1">Visa Expiry</p>
                          <p className="text-xs font-bold">{profile.visaExpiry ? new Date(profile.visaExpiry).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) : 'N/A'}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 gap-2">
                        <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-100 flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <Headphones className="w-4 h-4 text-zinc-400" />
                            <span className="font-bold text-xs">Listening</span>
                          </div>
                          <span className="font-black text-blue-600 text-sm">{progress.listening}%</span>
                        </div>
                        <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-100 flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <Eye className="w-4 h-4 text-zinc-400" />
                            <span className="font-bold text-xs">Reading</span>
                          </div>
                          <span className="font-black text-sm">{progress.reading}%</span>
                        </div>
                        <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-100 flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <Mic2 className="w-4 h-4 text-zinc-400" />
                            <span className="font-bold text-xs">Speaking</span>
                          </div>
                          <span className="font-black text-sm">{progress.speaking}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-zinc-900 text-white p-8 rounded-[2.5rem] text-center space-y-4">
                      <Flame className="w-10 h-10 mx-auto text-orange-500 fill-orange-500" />
                      <h4 className="text-xl font-bold italic">Keep the fire burning!</h4>
                      <p className="text-zinc-400 text-[10px] leading-relaxed uppercase tracking-wider font-bold">
                        Mission: Complete 6 more days to unlock the WEEKEND MOCK TEST and Advanced Modules.
                      </p>
                      <button 
                        onClick={() => { setFlow("dashboard"); }}
                        className="w-full bg-white text-zinc-900 py-4 rounded-xl font-bold mt-4"
                      >
                        Back to Game Path
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </main>
          </>
        )}

      </div>
    </div>
  );
};

export default App;
